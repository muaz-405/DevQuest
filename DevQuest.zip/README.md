# DevQuest - Programming Forum Platform

A collaborative programming forum platform designed to facilitate code sharing, learning, and community interaction.

## Features

- User authentication and profile management
- Thread creation and browsing by categories
- Code snippet sharing with syntax highlighting
- Reputation system with badges
- Responsive design for all devices

## Heroku Deployment Instructions

### Prerequisites

1. Create a [Heroku](https://www.heroku.com/) account if you don't have one
2. Install the [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli)

### Deployment Steps

1. Log in to Heroku CLI:
   ```
   heroku login
   ```

2. Create a new Heroku app:
   ```
   heroku create devquest-forum
   ```
   Note: Replace `devquest-forum` with your preferred name (must be unique on Heroku)

3. Add a Postgres database (if using the database storage option):
   ```
   heroku addons:create heroku-postgresql:mini
   ```

4. Set environment variables:
   ```
   heroku config:set NODE_ENV=production
   heroku config:set SESSION_SECRET=your_session_secret_here
   ```
   Note: Replace `your_session_secret_here` with a strong random string

5. Deploy the app:
   ```
   git push heroku main
   ```

6. Open the deployed app:
   ```
   heroku open
   ```

### Troubleshooting

- If you encounter any issues, check the logs:
  ```
  heroku logs --tail
  ```

- For database issues, you can connect to the Postgres database:
  ```
  heroku pg:psql
  ```

## Local Development

1. Install dependencies:
   ```
   npm install
   ```

2. Start the development server:
   ```
   npm run dev
   ```

3. Build for production:
   ```
   npm run build
   ```

4. Run in production mode:
   ```
   npm start
   ```

## Technology Stack

- Frontend: React, TailwindCSS, shadcn/ui components
- Backend: Node.js, Express
- Database: PostgreSQL (optional)
- Authentication: Passport.js