
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";

export default function Hero() {
  const { user } = useAuth();

  return (
    <div className="relative overflow-hidden">
      <Carousel
        className="absolute inset-0 w-full h-full"
        opts={{
          loop: true,
          dragFree: true,
          align: "center"
        }}
        plugins={[
          Autoplay({
            delay: 2000,
            stopOnInteraction: true
          })
        ]}
      >
        <CarouselContent>
          <CarouselItem>
            <div 
              className="w-full h-screen bg-cover bg-center transition-opacity duration-1000 ease-in-out animate-fade-in"
              style={{
                backgroundImage: 'url("https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=3270&auto=format&fit=crop")',
                filter: 'brightness(0.5)',
                minHeight: '100vh'
              }}
            />
          </CarouselItem>
          <CarouselItem>
            <div 
              className="w-full h-screen bg-cover bg-center transition-opacity duration-1000 ease-in-out animate-fade-in"
              style={{
                backgroundImage: 'url("https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=3270&auto=format&fit=crop")',
                filter: 'brightness(0.5)',
                minHeight: '100vh'
              }}
            />
          </CarouselItem>
          <CarouselItem>
            <div 
              className="w-full h-screen bg-cover bg-center transition-opacity duration-1000 ease-in-out animate-fade-in"
              style={{
                backgroundImage: 'url("https://images.unsplash.com/photo-1550439062-609e1531270e?q=80&w=3270&auto=format&fit=crop")',
                filter: 'brightness(0.5)',
                minHeight: '100vh'
              }}
            />
          </CarouselItem>
        </CarouselContent>
      </Carousel>

      <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
            <span className="block">Connect with developers</span>
            <span className="block bg-clip-text text-transparent bg-gradient-to-r from-emerald-300 to-sky-300">
              Share knowledge. Grow together.
            </span>
          </h1>
          <div className="mt-6 max-w-md mx-auto space-y-4 text-base sm:text-lg md:mt-8 md:text-xl md:max-w-3xl">
            <p className="text-blue-100">Join our programming community</p>
            <p className="text-blue-100">
              Connect with like-minded developers, share your knowledge, and
              grow your skills through meaningful discussions.
            </p>
          </div>
          <div className="mt-8 max-w-md mx-auto sm:flex sm:justify-center md:mt-10">
            {!user ? (
              <>
                <div className="rounded-md shadow">
                  <Link href="/auth?tab=register">
                    <Button className="w-full flex items-center justify-center px-8 py-3 md:py-4 md:text-lg md:px-10 bg-gradient-to-r from-emerald-400 to-sky-500 hover:from-emerald-500 hover:to-sky-600">
                      Join the community
                    </Button>
                  </Link>
                </div>
                <div className="mt-3 rounded-md shadow sm:mt-0 sm:ml-3">
                  <Link href="/auth">
                    <Button
                      variant="outline"
                      className="w-full flex items-center justify-center px-8 py-3 md:py-4 md:text-lg md:px-10 bg-white text-indigo-800 font-medium border-2 border-white hover:bg-white/90 hover:text-indigo-900 transition-all"
                    >
                      Log in
                    </Button>
                  </Link>
                </div>
              </>
            ) : (
              <>
                <div className="rounded-md shadow">
                  <Link href="/categories">
                    <Button className="w-full flex items-center justify-center px-8 py-3 md:py-4 md:text-lg md:px-10 bg-gradient-to-r from-emerald-400 to-sky-500 hover:from-emerald-500 hover:to-sky-600">
                      Browse discussions
                    </Button>
                  </Link>
                </div>
                <div className="mt-3 rounded-md shadow sm:mt-0 sm:ml-3">
                  <Link href="/profile">
                    <Button
                      variant="outline"
                      className="w-full flex items-center justify-center px-8 py-3 border border-transparent md:py-4 md:text-lg md:px-10 text-white border-white/30 hover:bg-white/10"
                    >
                      View profile
                    </Button>
                  </Link>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
