#!/bin/bash

# Make script executable: chmod +x setup-heroku.sh
# Run with: ./setup-heroku.sh your-app-name

if [ -z "$1" ]; then
  echo "Please provide a name for your Heroku app."
  echo "Usage: ./setup-heroku.sh your-app-name"
  exit 1
fi

APP_NAME=$1
SESSION_SECRET=$(openssl rand -hex 32)

echo "Setting up $APP_NAME on Heroku..."

# Make sure Heroku CLI is installed
if ! command -v heroku &> /dev/null; then
  echo "Heroku CLI is not installed. Please install it first."
  echo "Visit: https://devcenter.heroku.com/articles/heroku-cli"
  exit 1
fi

# Check if logged in to Heroku
heroku whoami &> /dev/null
if [ $? -ne 0 ]; then
  echo "You need to log in to Heroku first."
  heroku login
fi

# Create the app
echo "Creating Heroku app: $APP_NAME"
heroku create $APP_NAME

# Add PostgreSQL addon (if using database)
echo "Adding PostgreSQL addon..."
heroku addons:create heroku-postgresql:mini --app $APP_NAME

# Set environment variables
echo "Setting environment variables..."
heroku config:set NODE_ENV=production --app $APP_NAME
heroku config:set SESSION_SECRET=$SESSION_SECRET --app $APP_NAME

echo "Heroku app setup complete!"
echo ""
echo "Next steps:"
echo "1. Deploy your app with: git push heroku main"
echo "2. Open your app with: heroku open --app $APP_NAME"
echo ""
echo "For troubleshooting, check the logs with: heroku logs --tail --app $APP_NAME"